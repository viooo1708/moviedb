<footer class="footer mt-auto py-3 bg-light">
    <div class="container text-center">
        <span class="text-muted">© <?php echo e(date('Y')); ?> Jurusan Teknologi Informasi - Politeknik Negeri Padang</span>
    </div>
</footer>
<?php /**PATH D:\PHP 8.3\movie-db\resources\views/layouts/footer.blade.php ENDPATH**/ ?>