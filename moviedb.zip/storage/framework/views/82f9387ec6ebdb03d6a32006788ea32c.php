<?php $__env->startSection('title', 'Daftar Film'); ?>
<?php $__env->startSection('navMovies', 'active'); ?>
<?php $__env->startSection('searchAction', route('movies.index')); ?>


<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h1 class="mb-4">Daftar Film</h1>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Berhasil!</strong> <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create')): ?>
    
    <a href="<?php echo e(route('movies.create')); ?>" class="btn btn-primary mb-3">Input Film</a>
<?php endif; ?>
    
    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle text-center">
            <thead class="table-light">
                <tr>
                    <th>No</th>
                    <th>Judul</th>
                    <th>Kategori</th>
                    <th>Tahun</th>
                    <th>Actors</th>
                    <th>Cover</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($movies->firstItem() + $loop->index); ?></td>
                        <td><?php echo e($movie->title); ?></td>
                        <td><?php echo e($movie->category->category_name); ?></td>
                        <td><?php echo e($movie->year); ?></td>
                        <td><?php echo e($movie->actors); ?></td>
                        <td>
                            <img src="<?php echo e(filter_var($movie->cover_image, FILTER_VALIDATE_URL) ? $movie->cover_image : asset('storage/' . $movie->cover_image)); ?>"
                                 alt="<?php echo e($movie->title); ?>"
                                 width="100"
                                 class="img-fluid rounded">
                        </td>
                        <td>
                            <div class="btn-group">
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit')): ?>
                                
                                <a href="<?php echo e(route('movies.edit', $movie->id)); ?>"
                                   class="btn btn-sm btn-warning"
                                   title="Edit Film">
                                    <i class="bi bi-pencil-square fs-5"></i>
                                </a>
<?php endif; ?>
                                
                                <button type="button"
                                        class="btn btn-sm btn-info"
                                        data-bs-toggle="modal"
                                        data-bs-target="#detailModal<?php echo e($movie->id); ?>"
                                        title="Lihat Detail">
                                    <i class="bi bi-eye fs-5"></i>
                                </button>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete')): ?>
                                
                                <form action="<?php echo e(route('movies.destroy', $movie->id)); ?>"
                                      method="POST"
                                      class="d-inline"
                                      onsubmit="return confirm('Yakin ingin menghapus film ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit"
                                            class="btn btn-sm btn-danger"
                                            title="Hapus Film">
                                        <i class="bi bi-trash fs-5"></i>
                                    </button>
                                </form>
<?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    
    <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="detailModal<?php echo e($movie->id); ?>" tabindex="-1" aria-labelledby="detailModalLabel<?php echo e($movie->id); ?>" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">

                    <div class="modal-header">
                        <h5 class="modal-title" id="detailModalLabel<?php echo e($movie->id); ?>">Detail Film</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
                    </div>

                    <div class="modal-body">
                        <div class="text-center mb-3">
                            <img src="<?php echo e(filter_var($movie->cover_image, FILTER_VALIDATE_URL) ? $movie->cover_image : asset('storage/' . $movie->cover_image)); ?>"
                                 alt="<?php echo e($movie->title); ?>"
                                 class="img-fluid rounded shadow-sm"
                                 style="max-height: 200px;">
                        </div>
                        <p><strong>Judul:</strong> <?php echo e($movie->title); ?></p>
                        <p><strong>Slug:</strong> <?php echo e($movie->slug); ?></p>
                        <p><strong>Kategori:</strong> <?php echo e($movie->category->category_name); ?></p>
                        <p><strong>Tahun:</strong> <?php echo e($movie->year); ?></p>
                        <p><strong>Actors:</strong> <?php echo e($movie->actors); ?></p>
                        <p><strong>Sinopsis:</strong><br><?php echo e($movie->synopsis); ?></p>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    </div>

                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <div class="d-flex justify-content-center mt-4">
        <?php echo e($movies->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PHP 8.3\movie-db\resources\views/movies/index.blade.php ENDPATH**/ ?>