<?php $__env->startSection('title', 'Daftar Film'); ?>
<?php $__env->startSection('navMovies', 'active'); ?>
<?php $__env->startSection('searchAction', route('home')); ?>


<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
<div class="container mt-4">
    <h1 class="mb-4">Latest Movie</h1>

    
    <?php $__currentLoopData = $movies->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row mb-4">
            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6">
                    <div class="card mb-3 shadow-sm">
                        <div class="row g-0">
                            <div class="col-md-4">
                                <img src="<?php echo e(filter_var($movie->cover_image, FILTER_VALIDATE_URL) ? $movie->cover_image : asset('storage/' . $movie->cover_image)); ?>"
                                    alt="<?php echo e($movie->title); ?>"
                                    class="img-fluid rounded-start"
                                    style="height: 100%; object-fit: cover;">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($movie->title); ?></h5>
                                    <p class="card-text text-muted"><small><?php echo e($movie->category->category_name); ?> - <?php echo e($movie->year); ?></small></p>
                                    <p class="card-text"><?php echo e(\Illuminate\Support\Str::limit($movie->synopsis, 100, '...')); ?></p>
                                    <a href="#" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#detailModal<?php echo e($movie->id); ?>">
                                        View Details
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="modal fade" id="detailModal<?php echo e($movie->id); ?>" tabindex="-1" aria-labelledby="detailModalLabel<?php echo e($movie->id); ?>" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">

                            <div class="modal-header">
                                <h5 class="modal-title" id="detailModalLabel<?php echo e($movie->id); ?>">Detail Film</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
                            </div>

                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <img src="<?php echo e(filter_var($movie->cover_image, FILTER_VALIDATE_URL) ? $movie->cover_image : asset('storage/' . $movie->cover_image)); ?>" alt="<?php echo e($movie->title); ?>" class="img-fluid">
                                    </div>
                                    <div class="col-md-8">
                                        <p><strong>Judul:</strong> <?php echo e($movie->title); ?></p>
                                        <p><strong>Kategori:</strong> <?php echo e($movie->category->category_name); ?></p>
                                        <p><strong>Tahun:</strong> <?php echo e($movie->year); ?></p>
                                        <p><strong>Actors:</strong> <?php echo e($movie->actors); ?></p>
                                        <p><strong>Sinopsis:</strong><br><?php echo e($movie->synopsis); ?></p>
                                    </div>
                                </div>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                            </div>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <div class="d-flex justify-content-center mt-4">
        <?php echo e($movies->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PHP 8.3\movie-db\resources\views/home.blade.php ENDPATH**/ ?>