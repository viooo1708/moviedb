<?php $__env->startSection('title', 'Data Kategori'); ?>
<?php $__env->startSection('navKategori', 'active'); ?>
<?php $__env->startSection('searchAction', route('categories.index')); ?>


<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h1 class="mb-4">Daftar Kategori Film</h1>

    
    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
        <strong>Berhasil!</strong> <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    
    <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary mb-3">Input Kategori</a>

    
    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead class="table-light text-center align-middle">
                <tr>
                    <th>No</th>
                    <th>Nama Kategori</th>
                    <th>Deskripsi</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody class="text-center align-middle">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($categories->firstItem() + $loop->index); ?></td>
                        <td><?php echo e($category->category_name); ?></td>
                        <td><?php echo e($category->description); ?></td>
                        <td>
                            <div class="btn-group" role="group" aria-label="Aksi">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit')): ?>
                                
                                <a href="<?php echo e(route('categories.edit', $category->id)); ?>" class="btn btn-sm btn-warning me-2" title="Edit Kategori">
                                    <i class="bi bi-pencil-square fs-5"></i>
                                </a>
                                <?php endif; ?>
                                
                                <a href="#" class="btn btn-sm btn-info me-2" data-bs-toggle="modal" data-bs-target="#detailModal<?php echo e($category->id); ?>" title="Lihat Detail">
                                    <i class="bi bi-eye fs-5"></i>
                                </a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete')): ?>
                                
                                <form action="<?php echo e(route('categories.destroy', $category->id)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Yakin ingin menghapus kategori ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" title="Hapus Kategori">
                                        <i class="bi bi-trash fs-5"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="detailModal<?php echo e($category->id); ?>" tabindex="-1" aria-labelledby="detailModalLabel<?php echo e($category->id); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="detailModalLabel<?php echo e($category->id); ?>">Detail Kategori</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
                    </div>
                    <div class="modal-body">
                        <p><strong>Nama Kategori:</strong> <?php echo e($category->category_name); ?></p>
                        <p><strong>Deskripsi:</strong> <?php echo e($category->description); ?></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <div class="d-flex justify-content-center">
        <?php echo e($categories->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PHP 8.3\movie-db\resources\views/categories/index.blade.php ENDPATH**/ ?>