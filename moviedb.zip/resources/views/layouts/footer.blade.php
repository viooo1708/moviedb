<footer class="footer mt-auto py-3 bg-light">
    <div class="container text-center">
        <span class="text-muted">© {{ date('Y') }} Jurusan Teknologi Informasi - Politeknik Negeri Padang</span>
    </div>
</footer>
